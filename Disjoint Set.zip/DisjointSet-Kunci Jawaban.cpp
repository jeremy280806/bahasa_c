#include<stdio.h>
#include<stdlib.h>

struct Edge{
	int src;
	int dst;
};

struct Graph{
	int vCount;
	int eCount;
	Edge* edge;
};

Graph* createGraph(int vCount, int eCount){
	Graph* newGraph = (Graph*)malloc(sizeof(Graph));
	newGraph->vCount = vCount;
	newGraph->eCount = eCount;
	
	newGraph->edge = (Edge*)malloc(sizeof(Edge) * eCount);
	
	return newGraph;
}

void makeSet(int i, int parent[]){
	parent[i] = i;
}

int find(int i, int parent[]){
	if(parent[i] == i){
		return i;
	}else{
		//return find(parent[i],parent); without path compression
		
		//optimization with path compression
		parent[i] = find(parent[i],parent);
		return parent[i];
	}
}

void unionSet(int src, int dst, int parent[]){
	parent[src] = dst;
}

bool isCyclic(Graph* graph){
	int parent[graph->vCount+1]; // indexing kita mulai dari 1 - n
	
	for(int i =1;i<=graph->vCount;i++){
		// makeSet(i)
		makeSet(i, parent);
	}
	for(int i=0;i<graph->eCount;i++){
		int src = graph->edge[i].src;
		int dst = graph->edge[i].dst;
		
		int srcParent = find(src,parent);
		int dstParent = find(dst,parent);
		
		if(srcParent != dstParent){
			unionSet(srcParent, dstParent, parent);
		}else{
			return true; // Graph yang kita miliki cyclic
		}
	}
	return false; // Graph yang kita miliki tidak cyclic
}

int main(){
	Graph* graph1 = createGraph(4,4);
	
	/* Example:
     1 - - 4
     | \   |
     |  \  |
     |   \ |
     2     3 
	 */
	
	graph1->edge[0].src = 1;
	graph1->edge[0].dst = 2;
	
	graph1->edge[1].src = 1;
	graph1->edge[1].dst = 3;
	
	graph1->edge[2].src = 1;
	graph1->edge[2].dst = 4;
	
	graph1->edge[3].src = 3;
	graph1->edge[3].dst = 4;
	
	printf("Graph1 is %s\n", isCyclic(graph1) ? "Cyclic" : "Not Cyclic" );
	
	return 0;
}
